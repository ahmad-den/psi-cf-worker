import { TIMEOUTS } from "../config/constants"
import type { RequestParams } from "../types/psi"

export async function fetchPSIData(params: RequestParams, apiKey: string): Promise<any | null> {
  try {
    const psiUrl = buildPSIUrl(params, apiKey)

    const response = await fetch(psiUrl.toString(), {
      // @ts-ignore - cf property is specific to Cloudflare Workers
      cf: {
        timeout: TIMEOUTS.PSI_API,
      },
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("PSI API error:", response.status, errorText)
      return null
    }

    const data = (await response.json()) as Record<string, any>
    return {
      ...data,
      fromCache: false,
      fetchTimestamp: Date.now(),
    }
  } catch (error) {
    console.error("PSI fetch error:", error)
    return null
  }
}

function buildPSIUrl(params: RequestParams, apiKey: string): URL {
  const psiUrl = new URL("https://www.googleapis.com/pagespeedonline/v5/runPagespeed")
  psiUrl.searchParams.set("url", params.url)
  psiUrl.searchParams.set("strategy", params.strategy || "mobile")
  psiUrl.searchParams.set("key", apiKey)

  // Add categories
  if (params.category && params.category.length > 0) {
    params.category.forEach((cat) => {
      psiUrl.searchParams.append("category", cat)
    })
  }

  return psiUrl
}
