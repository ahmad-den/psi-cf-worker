import { DEFAULT_STRATEGY, DEFAULT_CATEGORIES } from "../config/constants"
import type { RequestParams } from "../types/psi"

export async function parseRequestParams(request: Request): Promise<RequestParams | null> {
  const url = new URL(request.url)
  const targetUrl = url.searchParams.get("url")

  if (!targetUrl) {
    return null
  }

  // Validate URL format
  try {
    new URL(targetUrl)
  } catch {
    return null
  }

  const strategy = (url.searchParams.get("strategy") as "mobile" | "desktop") || DEFAULT_STRATEGY
  const categories = url.searchParams.get("category")?.split(",") || [...DEFAULT_CATEGORIES]

  return {
    url: targetUrl,
    strategy,
    category: categories,
  }
}
