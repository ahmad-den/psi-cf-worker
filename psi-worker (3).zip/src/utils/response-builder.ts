interface SuccessResponseOptions {
  bypassCache: boolean
  cacheTtl: number
}

export function createErrorResponse(message: string, status: number): Response {
  return new Response(
    JSON.stringify({
      error: message,
      timestamp: new Date().toISOString(),
    }),
    {
      status,
      headers: {
        "Content-Type": "application/json",
        ...getCORSHeaders(),
      },
    },
  )
}

export function createSuccessResponse(data: any, options: SuccessResponseOptions): Response {
  return new Response(JSON.stringify(data), {
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": options.bypassCache ? "no-cache" : `public, max-age=${options.cacheTtl}`,
      "X-Cache-Status": data.fromCache ? "HIT" : "MISS",
      "X-Cache-TTL": options.cacheTtl.toString(),
      ...getCORSHeaders(),
    },
  })
}

function getCORSHeaders(): Record<string, string> {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, x-bypass-cache",
  }
}
